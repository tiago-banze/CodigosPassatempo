from django.apps import AppConfig


class FlightConfig(AppConfig):
    name = 'flight'
